#!/system/bin/sh
LOG="/data/local/tmp/dp_extreme_v2.log"
PATCH="/data/adb/modules/dp_enable_altmode_extreme_v2/dp_patch.dtbo"

SLOT=$(getprop ro.boot.slot_suffix)
ACTIVE="/dev/block/by-name/dtbo$SLOT"

echo "[EXTREME V2] DTBO slot $SLOT" >> $LOG

dd if=$PATCH of=$ACTIVE 2>/dev/null

for part in dtbo_a dtbo_b; do
    dd if=$PATCH of=/dev/block/by-name/$part 2>/dev/null
done

(
while true; do
    if ! strings $ACTIVE | grep -q "dp"; then
        echo "[EXTREME V2] DTBO lost restoring" >> $LOG
        dd if=$PATCH of=$ACTIVE 2>/dev/null
    fi
    sleep 15
done
) &
