#!/system/bin/sh
LOG="/data/local/tmp/dp_extreme_v2.log"
sleep 5
echo "[EXTREME V2] Boot $(date)" >> $LOG

while true; do

# USB Config
CONFIG_USB="/config/usb_gadget/g1"
if [ -d "$CONFIG_USB" ]; then
    echo "" > $CONFIG_USB/UDC 2>/dev/null
    echo "0xEF" > $CONFIG_USB/bDeviceClass 2>/dev/null
    ls /sys/class/udc > $CONFIG_USB/UDC 2>/dev/null
fi

# UDC force
for c in /sys/class/udc/*; do
    echo "super-speed-plus" > "$c/maximum_speed" 2>/dev/null
    echo "drd" > "$c/current_role" 2>/dev/null
done

# Type-C negotiation
for port in /sys/class/typec/port*; do
    echo "dual" > $port/power_role 2>/dev/null
    echo "host" > $port/data_role 2>/dev/null
    echo "dp" > $port/port0-partner/identity 2>/dev/null
done

# MUX force (best effort)
for mux in /sys/class/typec_mux/*; do
    echo "safe" > $mux/state 2>/dev/null
    echo "dp" > $mux/state 2>/dev/null
done

# DRM pipeline
for drm in /sys/class/drm/*; do
    echo on > $drm/power/control 2>/dev/null
done

# Hotplug simulation
for s in /sys/class/drm/card*/*/status; do
    echo detect > $s 2>/dev/null
done

# GPU trigger
echo "force_probe" > /sys/kernel/debug/dri/0/debug_state 2>/dev/null

echo "[EXTREME V2] cycle $(date)" >> $LOG
sleep 8
done
